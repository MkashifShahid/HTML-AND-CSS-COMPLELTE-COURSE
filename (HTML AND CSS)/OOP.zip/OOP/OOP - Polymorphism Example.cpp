#include<iostream>
#include<string>
using namespace std;

class person
{
	private:
		int id;
		string name;
	public:
		void setId(int Id)
		{
			id = Id;
		}
		int getId()
		{
			return id;
		}
		void setName(string Name)
		{
			name = Name;
		}
		string getName()
		{
			return name;
		}
};

class teacher : public person
{
	private:
		string qualification;
	public:
		void setQualification(string qualif)
		{
			qualification = qualif;
		}
		string getQualification()
		{
			return qualification;
		}
		
		int payment(int v)
		{
			return v;
		}
};

class pTeacher : public teacher
{
	private:
		int salary;
	public:
		void setSalary( int Salary )
		{
			salary = Salary;
		}
		int getSalary()
		{
			return salary;
		}
		
		int payment(int days)
		{
			int tax;
			int pay = days * 8000;
			if ( pay > 100000 ) {
				tax = pay * 5/100;
			}
			if ( 100000 < pay < 150000 ) {
				tax = pay * 10/100;
			}
			if ( 150000 < pay < 200000 ) {
				tax = pay * 15/100;
			}
			if ( 200000 < pay ) {
				tax = pay * 25/100;
			}
			pay = pay - tax;
			pay = pay + ( pay * 5/100 ) + ( pay * 15 / 100 );
			return pay;
		}
};

class visitTeacher : public teacher
{
	private:
		int honorarium;
	public:
		void setHonorarium( int Honorarium )
		{
			honorarium = Honorarium;
		}
		int getHonorarium()
		{
			return honorarium;
		}
		
		int payment(int hrs)
		{
			int tax;
			int pay = hrs * 1500;
			tax = pay * 5/100;
			pay = pay - tax;
			return pay;
		}
};

int main()
{
	int pay;
	
	pTeacher Hannan;
	visitTeacher Farrukh;
	
	//pTeacher
	
	cout << "\nEnter Days: ";
	cin >> pay;
	if ( pay > 31 ) {
		cout << "\nDays Cannot be More Than 30." << endl;
	}
	else {
		cout<<"\nSalary is: " << Hannan.payment(pay) << endl;
	}
	
	//visitTeacher
	
	cout << "\nEnter Working Hours: ";
	cin >> pay;
	cout<<"\nSalary is: "<<Farrukh.payment(pay) << endl;
	
}
