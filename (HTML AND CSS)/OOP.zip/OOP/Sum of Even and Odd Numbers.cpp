#include <iostream>
using namespace std;

//Main Function

int main() {
	int Arr[10], Even = 0, Odd = 0, i = 0;
	
	cout << "Enter 10 Numbers: " << endl;
	for ( i = 0; i < 10; i++ ) {
		cin >> Arr[i];
	}
	
	for ( i = 0; i < 10; i++ ) {
		if ( Arr[i] % 2 == 0 ) {
			Even = Even + Arr[i];
		}
		else {
			Odd = Odd + Arr[i];
		}
	}
	
	cout << "Sum of Even Numbers is: " << Even << endl;
	
	cout << "Sum of Odd Numbers is : " << Odd << endl;
	
	return 0;
}
