#include <iostream>
using namespace std;

//Main Function 

int main() {
	int Arr[10], Even = 0, i = 0;
	
	cout << "\nEnter 10 Numbers: " << endl;
	for ( i = 0; i < 10; i++ ) {
		cin >> Arr[i];
	} 
	
	for ( i = 0; i < 10; i++ ) {
		if ( Arr[i] % 2 == 0 ) {
			Even = Even * 0;
			cout << Even << " ";
		}
		else {
			cout << Arr[i] << " ";
		}
	}
	
	return 0;
}
