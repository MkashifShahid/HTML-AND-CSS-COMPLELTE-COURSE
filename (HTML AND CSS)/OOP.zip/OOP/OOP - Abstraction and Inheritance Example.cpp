# include <iostream>
# include <string>
using namespace std;

class person
{
	private:
		int id;
		string name;
	public:
		void setId(int Id)
		{
			id = Id;
		}
		int getId()
		{
			return id;
		}
		void setName(string Name)
		{
			name = Name;
		}
		string getName()
		{
			return name;
		}
};//end of Person class

class teacher : public person
{
	private:
		string qualification;
	public:
		void setQualification(string qualif)
		{
			qualification = qualif;
		}
		string getQualification()
		{
			return qualification;
		}
};//end of Teacher class

class pTeacher : public teacher
{
	private:
		int salary;
	public:
		void setSalary( int Salary )
		{
			salary = Salary;
		}
		int getSalary()
		{
			return salary;
		}
};//end pTeacher Class

class visitTeacher : public teacher
{
	private:
		int honorarium;
	public:
		void setHonorarium( int Honorarium )
		{
			honorarium = Honorarium;
		}
		int getHonorarium()
		{
			return honorarium;
		}
};

int main()
{
	int id;
	string name;
	string qualification;
	int salary;
	int honorarium;
	
	teacher Teacher;
	pTeacher Hannan;
	visitTeacher Farrukh;
	
	//pTeacher
	
	cout << "Enter Id of Permanent Teacher: ";
	cin >> id;
	Hannan.setId(id);
	
	cout << "Enter Name of Permanent Teacher: ";
	cin >> name;
	Hannan.setName(name);
	
	cout << "Enter Qualification of Permanent Teacher: ";
	cin >> qualification;
	Hannan.setQualification(qualification);
	
	cout << "Enter Salary of Permanent Teacher: ";
	cin >> salary;
	Hannan.setSalary(salary);
	
	//visitTeacher
	
	cout << "\nEnter Id of Visiting Teacher: ";
	cin >> id;
	Farrukh.setId(id);
	
	cout << "\nEnter Name of Visiting Teacher: ";
	cin >> name;
	Farrukh.setName(name);
	
	cout << "\nEnter Qualification of Visiting Teacher: ";
	cin >> qualification;
	Farrukh.setQualification(qualification);
	
	cout << "\nEnter Honorarium of Visiting Teacher: ";
	cin >> honorarium;
	Farrukh.setHonorarium(honorarium);
	
	cout << "\n*************Output*************\n" << endl;
	
	//pTeacher
	
	cout << "\nId of Permanent Teacher is: ";
	cout << Hannan.getId() << endl;
	
	cout << "\nName of Permanent Teacher is: ";
	cout << Hannan.getName() << endl;
	
	cout << "\nQualification of Permanent Teacher is: ";
	cout << Hannan.getQualification() << endl;
	
	cout << "\nSalary of Permanent Teacher is: ";
	cout << Hannan.getSalary() << endl;
	
	//visitTeacher
	
	cout << "\nId of Visiting Teacher is: ";
	cout << Farrukh.getId() << endl;
	
	cout << "\nName of Visiting Teacher is: ";
	cout << Farrukh.getName() << endl;
	
	cout << "\nQualification of Visiting Teacher is: ";
	cout << Farrukh.getQualification() << endl;
	
	cout << "\nHonorariam of Visiting Teacher is: ";
	cout << Farrukh.getHonorarium() << endl;
	
	return 0;
	
}
