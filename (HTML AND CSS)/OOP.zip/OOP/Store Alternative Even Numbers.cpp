#include <iostream>
using namespace std;

//Class Decleration

class EN {
	private:
		int Arr[50];
		int counter;
	
	public:
		EN() {
			counter = 0;	
		}
		
	//Condition Check Function
	
	bool conditionCheck( int num1, int num2 ) {
		cout << "Condition Check" << endl;
		
		if ( num1 >= num2 ) {
			return false;
		}
		else if ( num1 < 0 || num2 < 0 ) {
			return false;
		}
		else if ( ( ( num2 - num1 ) / 4 ) < 25 ) {
			return false;
		}
		else {
			return true;
		}
	}
	
	//Alternative Even Numbers
	
	int altEvenNum( int num1, int num2 ) {
		cout << "Alternate Even Numbers Stored!" << endl;
		
		if ( num1 % 2 == 0 ) {
			for ( int i = 0; i <= num2; i = i +4 ) {
				Arr[counter] = i;
				counter++;
			}
		}
		else {
			num1 = num1 + 1;
			for ( int i = 0; i <= num2; i = i + 4 ) {
				Arr[counter] = i;
				counter++;
			}
		}
	}
	
	//View Numbers
	
	void View() {
		for ( int i = 0; i < counter; i++ ) {
		cout << Arr[i] << ", ";
		}
	}
};

int main() {
	int num1 = 0, num2 = 0, opt = 1;
	EN Alt;
	
	while ( opt != 0 ) {
		cout << "\nPress 1 to Get Two Numbers. " << endl;
		cout << "Press 2 to View Numbers. " << endl;
		cout << "Press 0 to EXIT. " << endl;
		cout << "\nEnter Your Choice: ";
		cin >> opt;
		
		//Switch & Case
		
		switch ( opt ) {
			case 1:
				cout << "\nEnter 1st Number: ";
				cin >> num1;
				cout << "Enter 2nd Number: ";
				cin >> num2;
				Alt.conditionCheck(num1, num2);
				cout << endl;
				Alt.altEvenNum(num1, num2);
				cout << endl;
				break;
				
			case 2:
				cout << "Alternative Even Numbers in the Array are: ";
				Alt.View();
				cout << endl;
				break;
		}
	}
	
	return 0;
}
