#include <iostream>
using namespace std;

//Declare Array

int Arr[5];
int counter;

//Add Function

int Add ( int num ) {
	Arr[counter] = num;
	counter++;
	cout << "Congratulations! Number Inserted Successfully." << endl;
}

//Delete Function

int Delete ( int index ) {
		if ( counter == 0 ) {
			cout << "Empty.";
			return 0;
		}
		else if ( index < 0 || index >= counter ) {
			cout << "Invalid Index.";
			return 0;
		}
		else if ( index > 0 && index < counter ) {
			Arr[index] = Arr[counter - 1];
			counter--;
			cout << "Number Deleted." << endl;
			return 0;
		}
}

//View Function

int View() {
	cout << endl << endl << "Array Numbers are: ";
	for ( int i = 0; i < counter; i++ ) {
		cout << Arr[i] << ", ";
	}
}

//Main Function

int main() {
	int num = 0, opt = 1;
	
	while ( opt != 0 ) {
		cout << "\nPress 1 to Add Numbers in Array. " << endl;
		cout << "Press 2 to View Numbers in Array. " << endl;
		cout << "Press 3 to Delete Numbers from Array. " << endl;
		cout << "Press 0 to EXIT. " << endl;
		cout << "\nEnter Your Choice: ";
		cin >> opt;
		
		//Switch & Case
		
		switch( opt ) {
			case 1:
				cout << "\nEnter a Number: ";
				cin >> num;
				
				if ( counter < 5 ) {
					Add(num);
				}
				else {
					cout << "\nSorry Number not Inserted." << endl << endl;
				}
				break;
				
			case 2:
				cout << "\nNumbers in Array are: ";
				View();
				cout << endl;
				break;
				
			case 3:
				cout << "\nEnter Index Number to Delete from Array. ";
				cin >> num;
				Delete(num);
				break;
		}
	}
	
	return 0;
}
