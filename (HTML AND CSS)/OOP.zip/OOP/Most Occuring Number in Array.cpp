#include <iostream>
using namespace std;

class Occurring
{
private:
    int Arr[20];
    int counter = 0;

public:
    Occurring()
    {
        counter = 0;
    }

    void getNums(int N)
    {
        if (counter >= 20)
        {
            return;
        }
        else
        {
            Arr[counter] = N;
            counter++;
        }
    }

    void viewNums(void)
    {
        for (int i = 0; i < counter; i++)
        {
            cout << Arr[i] << ", ";
        }
    }
};

int main()
{
    int a, opt = 1;
    Occurring Obj;

    while (opt != 0)
    {
        cout << "\nPress 1 to Get Numbers." << endl;
        cout << "Press 2 to View Numbers." << endl;
        cout << "Press 3 to See the Most Occurring Number in Array." << endl;
        cout << "Press 0 to Exit." << endl;
        cout << "\nEnter Your Choice: ";
        cin >> opt;

        switch (opt)
        {
        case 1:
            for (int i = 0; i < 20; i++)
            {
                cout << "\nEnter a Number: ";
                cin >> a;
                Obj.getNums(a);
            }
            break;

        case 2:
            cout << "\nThe Numbers are: ";
            Obj.viewNums();
            cout << endl;
            break;
        }
    }

    return 0;
}