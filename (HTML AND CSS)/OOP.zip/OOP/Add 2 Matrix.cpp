#include<iostream>
using namespace std;

class Matrix {
	private:
		int Arr1[100][100];
		int Arr2[100][100];
		int Sum[100][100];
		int row;
		int col;
		
	public:
		Matrix() {
			row = col = 0;
		}
		
	void getValues1( int row, int col ) {
		for ( int r = 0; r < row; r++ ) {
			for ( int c = 0; c < col; c++ ) {
				cout << "\nEnter Value: ";
				cin >> Arr1[r][c];
			}
		}
	}
	
	void getValues2( int row, int col ) {
		for ( int r= 0; r < row; r++ ) {
			for ( int c = 0; c < col; c++ ) {
				cout << "\nEnter Value: ";
				cin >> Arr2[r][c];
			}
		}
	}
	
	void Add( int row, int col ) {
		for ( int r = 0; r < row; ++r ) {
			for ( int c = 0; c < col; ++c ) {
				Sum[r][c] = Arr1[r][c] + Arr2[r][c];
			}
		}
		//View Sum
		for ( int r = 0; r < row; ++r ) {
			for ( int c = 0; c < col; ++c ) {
				cout << Sum[r][c] << ", ";
			}
		}
		
	}
};

int main() {
	int Num, opt = 1, row = 0, col = 0;
	Matrix M;
	
	while ( opt != 0 ) {
		cout << "\nPress 1 to Get Numbers." << endl;
		cout << "Press 2 to Add Two Matrices." << endl;
		cout << "Press 0 to Exit." << endl;
		cout << "\nEnter Your Choice: ";
		cin >> opt;
		
		switch( opt ) {
			case 1:
				cout << "\nEnter the Size of Row: ";
				cin >> row;
				cout << "\nEnter the Size of Col: ";
				cin >> col;
				if( ! ( ( row > 0 && row < 6 ) && ( col > 0 && col < 6 ) ) ) {
					cout << "\nEntered Order is Invalid.";
				}
				else {
					cout << "\nEnter Values for 1st Matrix: " << endl;
					M.getValues1( row, col );
					cout << "\nEnter values for 2nd Matrix: " << endl;
					M.getValues2( row, col );
				}
				break;
				
			case 2:
				cout << "\nSum is: ";
				M.Add( row, col );
				cout << endl;
				break;
				
			default:
				break;
		}
	}
	
	return 0;

}
