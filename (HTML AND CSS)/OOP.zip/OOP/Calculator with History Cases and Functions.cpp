#include <iostream>
using namespace std;

int Arr[5];
int counter;

class Calc {
	public:
		int num1, num2, opt;
};

//Functions

int Add( int n1, int n2 ) {
	Arr[counter++] = n1 + n2;
	return( n1 + n2 );
}

int Subtract( int n1, int n2 ) {
	Arr[counter++] = n1 - n2;
	return( n1 - n2 );
}

int Multiply( int n1, int n2 ) {
	Arr[counter++] = n1 * n2;
	return ( n1 * n2 );
}

int Divide( int n1, int n2 ) {
	Arr[counter++] = n1 / n2;
	return( n1 / n2 );
}

void viewHistory() {
	for ( int i = 0; i < counter; i++ ) {
		cout << Arr[i] << ", ";
	}
}

//Cases

void case1( Calc Casio ) {
	cout << "\nEnter 1st Number: ";
	cin >> Casio.num1;
	cout << "Enter 2nd Number: ";
	cin >> Casio.num2;
	cout << "Addition: " << Add( Casio.num1, Casio.num2 ) << endl;
}

void case2( Calc Casio ) {
	cout << "\nEnter 1st Number: ";
	cin >> Casio.num1;
	cout << "Enter 2nd Number: ";
	cin >> Casio.num2;
	cout << "Subtraction: " << Subtract( Casio.num1, Casio.num2 ) << endl;
}

void case3( Calc Casio ) {
	cout << "\nEnter 1st Number: ";
	cin >> Casio.num1;
	cout << "Enter 2nd Number: ";
	cin >> Casio.num2;
	cout << "Multiplication: " << Multiply( Casio.num1, Casio.num2 ) << endl;
}

void case4( Calc Casio ) {
	cout << "\nEnter 1st Number: ";
	cin >> Casio.num1;
	cout << "Enter 2nd Number: ";
	cin >> Casio.num2;
	cout << "Division: " << Divide( Casio.num1, Casio.num2 ) << endl;
}

void case5( Calc Casio ) {
	cout << "History: ";
	viewHistory();
}

//Conditions

void conditions( Calc Casio ) {
	switch ( Casio.opt ) {
		case 1:
			case1(Casio);
			break;
			
		case 2:
			case2(Casio);
			break;
			
		case 3:
			case3(Casio);
			break;
			
		case 4:
			case4(Casio);
			break;
			
		case 5:
			case5(Casio);
			break;
			
		default:
			cout << "\nSelect from the Above Menu." << endl;
	}
}

//Menu

int menu( Calc Casio ) {
	while ( Casio.opt != 0 ) {
		cout << "\nPress 1 for Addition. " << endl;
		cout << "Press 2 for Subtraction. " << endl;
		cout << "Press 3 for Multiplication. " << endl;
		cout << "Press 4 for Divison. " << endl;
		cout << "Press 5 to View History. " << endl;
		cout << "Press 0 to EXIT. " << endl;
		cout << "Enter Your Choice: ";
		cin >> Casio.opt;
		
		conditions( Casio );
	}
}

//Variable Function

void variables() {
	Calc Casio;
	
	Casio.num1;
	Casio.num2;
	Casio.opt;
	
	menu(Casio);
}

//Main Function

int main() {
	
	variables();
	
	return 0;
}
