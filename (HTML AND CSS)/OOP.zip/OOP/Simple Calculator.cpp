#include<iostream>
using namespace std;

//Main Function

int main() {
	int opt = 1;
	float num1 = 0, num2 = 0;
	
//	While Loop

	while ( opt != 0 ){
		cout << "\nPress 1 for Addition." << endl;
		cout << "Press 2 for Subtraction." << endl;
		cout << "Press 3 for Multiplication." << endl;
		cout << "Press 4 for Division." << endl << endl;
		cout << "Enter Your Choice: ";
		cin >> opt;
		
//		Switch & Case

		switch( opt ){
			case 1:
				cout << "\nEnter 1st Number: ";
				cin >> num1;
				cout << "Enter 2nd Number: ";
				cin >> num2;
				cout << "\nAddition: " << num1 + num2 << endl;
				break;
				
			case 2:
				cout << "\nEnter 1st Number: ";
				cin >> num1;
				cout << "Enter 2nd Number: ";
				cin >> num2;
				cout << "\nSubtraction: " << num1 - num2 << endl;
				break;
				
			case 3:
				cout << "\nEnter 1st Number: ";
				cin >> num1;
				cout << "Enter 2nd Number: ";
				cin >> num2;
				cout << "\nMultiplication: " << num1 * num2 << endl;
				break;
				
			case 4:
				cout << "\nEnter 1st Number: ";
				cin >> num1;
				cout << "Enter 2nd Number: ";
				cin >> num2;
				cout << "\nDivision: " << num1 / num2 << endl;
				break;
				
			default:
				cout << "\nSelect from the Above Menu." << endl;
		}
	}
	
	return 0;
}
