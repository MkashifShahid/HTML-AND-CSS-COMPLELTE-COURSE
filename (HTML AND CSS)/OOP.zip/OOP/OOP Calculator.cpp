#include <iostream>
using namespace std;

class Calc {
	private:
		int NA[10];
		int counter;
		
	public:
		Calc() {
			counter = 0;
		}
		
		//Add Method
		
		int Add ( int num1, int num2 ) {
			NA[counter++] = num1 + num2;
			return ( num1 + num2 );
		}
		
		//Subtract Method
		
		int Subtract ( int num1, int num2 ) {
			NA[counter++] = num1 - num2;
			return ( num1 - num2 );
		}
		
		//Multiply Method
		
		int Multiply ( int num1, int num2 ) {
			NA[counter++] = num1 * num2;
			return ( num1 * num2);
		}
		
		//Division Method
		
		int Divide ( int num1, int num2 ) {
			NA[counter++] = num1 / num2;
			return ( num1 / num2 );
		} 
		
		//History View Method
		
		void viewHistory() {
			for ( int i = 0; i < counter; i++ ) {
				cout << NA[i] << ", ";
			}
		}
};

//Main Function

int main() {
	int n1 = 0, n2 = 0, opt = 1;
	Calc Casio;
	
	while ( opt != 0 ) {
		cout << "\nPress 1 for Addition." << endl;
		cout << "Press 2 for Subtraction." << endl;
		cout << "Press 3 for Multiplication." << endl;
		cout << "Press 4 for Division." << endl;
		cout << "Press 5 to View History." << endl;
		cout << "Press 0 to EXIT: " << endl;
		cout << "\nEnter Your Choice: ";
		cin >> opt;
		
		//Switch & Case
		
		switch ( opt ) {
			case 1:
				cout << "\nEnter 1st Number: ";
				cin >> n1;
				cout << "Enter 2nd Number: ";
				cin >> n2;
				cout << "\nAddition: " << Casio.Add( n1, n2 ) << endl;
				break;
				
			case 2:
				cout << "\nEnter 1st Number: ";
				cin >> n1;
				cout << "Enter 2nd Number: ";
				cin >> n2;
				cout << "\nSubtract: " << Casio.Subtract( n1, n2 ) << endl;
				break;
				
			case 3:
				cout << "\nEnter 1st Number: ";
				cin >> n1;
				cout << "Enter 2nd Number: ";
				cin >> n2;
				cout << "\nMultiplication: " << Casio.Multiply( n1, n2 ) << endl;
				break;
				
			case 4:
				cout << "\nEnter 1st Number: ";
				cin >> n1;
				cout << "Enter 2nd Number: ";
				cin >> n2;
				cout << "\nDivision: " << Casio.Divide( n1, n2 ) << endl;
				break;
				
			case 5:
				cout << "\nHistory: ";
				Casio.viewHistory();
				cout << endl;
				break;
				
			default:
				cout << "\nSelect from Above Menu." << endl;
		}
	}
}
