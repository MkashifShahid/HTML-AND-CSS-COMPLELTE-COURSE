#include <iostream>
using namespace std;

//Declarations

int Arr[5];
int counter;

//Class

class Calculator{
	public:
		int num1, num2, opt;
};
//		Methods

		int Add( int num1, int num2 ) {
			Arr[counter++] = num1 + num2;
			return( num1 + num2 );
		}
		
		int Subtract( int num1, int num2 ) {
			Arr[counter++] = num1 - num2;
			return( num1 - num2 );
		}
		
		int	Multiply( int num1, int num2 ) {
			Arr[counter++] = num1 * num2;
			return( num1 * num2 );
		}
		
		int Divide( int num1, int num2 ) {
			Arr[counter++] = num1 / num2;
			return( num1 / num2 );
		}
		
		void viewHistory() {
			for ( int i = 0; i < counter; ++i ) {
				cout << Arr[i] << ", ";
			}
		}

//Menu Function

int menu ( Calculator Calc ) {
	
//	While Loop

	while ( Calc.opt != 0 ) {
		cout << "\nPress 1 for Addition. " << endl;
		cout << "Press 2 for Subtraction. " << endl;
		cout << "Press 3 for Multiplication. " << endl;
		cout << "Press 4 for Division. " << endl;
		cout << "Press 5 to View History. " << endl;
		cout << "Press 0 to EXIT." << endl;
		cout << "\nEnter Your Choice: ";
		cin >> Calc.opt;
			
//		Switch & Case

		switch ( Calc.opt ) {
			case 1:
				cout << "\nEnter 1st Number: ";
				cin >> Calc.num1;
				cout << "Enter 2nd Number: ";
				cin >> Calc.num2;
				cout << "\nAddition: " << Add( Calc.num1, Calc.num2 ) << endl;;
				break;
					
			case 2:
				cout << "\nEnter 1st Number: ";
				cin >> Calc.num1;
				cout << "Enter 2nd Number: ";
				cin >> Calc.num2;
				cout << "\nSubtraction: " << Subtract( Calc.num1, Calc.num2 ) << endl;
				break;
					
			case 3:
				cout << "\nEnter 1st Number: ";
				cin >> Calc.num1;
				cout << "Enter 2nd Number: ";
				cin >> Calc.num2;
				cout << "\nMultiplication: " << Multiply( Calc.num1, Calc.num2 ) << endl;
				break;
					
			case 4:
				cout << "\nEnter 1st Number: ";
				cin >> Calc.num1;
				cout << "Enter 2nd Number: ";
				cin >> Calc.num2;
				cout << "\nDivision: " << Divide( Calc.num1, Calc.num2 ) << endl;
				break;
					
			case 5:
				cout << "History: ";
				viewHistory();
				cout << endl;
				break;
		}
	}
}

//Main Function

int main() {
	Calculator Calc;
	
	Calc.num1;
	Calc.num2;
	Calc.opt;
	
	menu(Calc);
	
	return 0;
}
