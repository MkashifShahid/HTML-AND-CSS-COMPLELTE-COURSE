#include <iostream>
using namespace std;

//Main Function

int main() {
	int Arr[30], size, position, i;
	
	cout << "\nEnter Size of Array ( Max:30 ): " << endl;
	cin >> size;
	
	cout << "\nEnter the Numbers: ";
	for ( i = 0; i < size; i++ ) {
		cin >> Arr[i];
	}
	
	cout << "\nEnter the Position where you want to Delete: ";
	cin >> position;
	
	for ( i = position - 1; i < size; i++ ) {
		Arr[i] = Arr[i+1];
	}
	size--;
	
	for ( i = 0; i < size; i++ ) {
		cout << " " << Arr[i];
	} 
	
	return 0;
}
