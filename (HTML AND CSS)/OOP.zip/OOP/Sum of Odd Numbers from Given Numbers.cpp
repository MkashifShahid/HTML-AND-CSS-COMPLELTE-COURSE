#include <iostream>
using namespace std;

//Main Function

int main() {
	int Arr[20], Even = 0, Odd = 0, i = 0;
	
	cout << "Enter 20 Numbers: " << endl;
	for ( i = 0; i < 20; i++ ) {
		cin >> Arr[i];
	}
	
	for ( i = 0; i < 20; i++ ) {
		if ( Arr[i] % 2 == 0 ) {
			Even = 0;
		}
		else {
			Odd = Odd + Arr[i];
		}
	}
	
	cout << "Sum of Odd Numbers is: " << Odd << endl;
	
	return 0;
}
