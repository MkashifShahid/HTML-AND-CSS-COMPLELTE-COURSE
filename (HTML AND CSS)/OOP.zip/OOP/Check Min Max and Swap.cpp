#include <iostream>
using namespace std;

class MinMax
{
private:
    int Array[20];
    int counter;
    int sn;
    int si;
    int ln;
    int li;

public:
    MinMax()
    {
        counter = 0;
        si = 0;
        li = 0;
        sn = Array[0];
        ln = Array[0];
    }

    void getNum(int N)
    {
        for (int i = 0; i < counter; i++)
        {
            Array[counter] = N;
            counter++;
        }
    }

    void viewNum()
    {
        for (int i = 0; i < counter; i++)
        {
            cout << Array[i] << ", ";
        }
    }

    void checkMinMax()
    {
        int i;
        for (i = 0; i < counter; i++)
        {
            if (sn < Array[i])
            {
                sn = Array[i];
                si = i;
            }

            if (ln > Array[i])
            {
                ln = Array[i];
                li = i;
            }
        }
    };

    void swapNum(int swap)
    {
        swap = sn;
        sn = ln;
        ln = swap;
    }
};

int main()
{
    int num, opt = 1;
    MinMax Obj;

    while (opt != 0)
    {
        cout << "\nPress 1 to Get Numbers." << endl;
        cout << "Press 2 to View Numbers." << endl;
        cout << "Press 3 to Check Min and Max Numbers." << endl;
        cout << "Press 4 to Swap Min and Max Numbers." << endl;
        cout << "Press 0 to Exit." << endl;
        cout << "\nEnter Your Choice: ";
        cin >> opt;

        switch (opt)
        {
        case 1:
            for (int i = 0; i < 20; i++)
            {
                cout << "\nEnter a Number: ";
                cin >> num;
                Obj.getNum(num);
            }
            break;

        case 2:
            cout << "\nNumbers are :";
            Obj.viewNum();
            break;
        }
    }
}