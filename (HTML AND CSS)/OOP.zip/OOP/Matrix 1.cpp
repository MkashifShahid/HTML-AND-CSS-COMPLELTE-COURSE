#include <iostream>
using namespace std;

class Matrix
{
private:
    int MA[5][5];
    int row;
    int col;

public:
    Matrix()
    {
        row = 0;
        col = 0;
    }

    void getValues(int N)
    {
        if (row >= 5 && col >= 5)
        {
            return;
        }
        else
        {
            MA[row][col] = N;
            row++;
            col++;
        }
    }

    void viewValues()
    {
        for (int r = 0; r < 5; r++)
        {
            for (int c = 0; c < 5; c++)
            {
                cout << MA[row][col] << ", ";
            }
        }
    }
};

int main()
{
    int a, opt = 1;
    Matrix matrix;

    while (opt != 0)
    {
        cout << "\nPress 1 to Get Values." << endl;
        cout << "Press 2 to View Values." << endl;
        cout << "Press 0 to Exit." << endl;
        cout << "\nEnter Your Choice: ";
        cin >> opt;

        switch (opt)
        {
        case 1:
            for (int r = 0; r < 5; r++)
            {
                for (int c = 0; c < 5; c++)
                {
                    cout << "\nEnter a Number: ";
                    cin >> a;
                    matrix.getValues(a);
                }
            }
            break;
        case 2:
            cout << "\nThe Values are: ";
            matrix.viewValues();
            break;
        }
    }

    return 0;
}