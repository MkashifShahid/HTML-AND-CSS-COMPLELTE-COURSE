#include<iostream>
using namespace std;

class Matrix {
	private:
		int Arr[5][5];
		int row;
		int col;
		
	public:
		Matrix() {
			row = col = 0;
		}
		
	void getValues( int row, int col ) {
		for ( int r = 0; r < row; r++ ) {
			for ( int c = 0; c < col; c++ ) {
				cout << "\nEnter Value: ";
				cin >> Arr[r][c];
				cout << "\nSuccess." << endl;
			}
		}
	}
	
	void viewValues( int row, int col ) {
		for ( int r = 0; r < row; r++ ) {
			for ( int c = 0; c < col; c++ ) {
				cout << Arr[r][c] << ", ";
			}
		}
	}
};

int main() {
	int Num, opt = 1, row = 0, col = 0;
	Matrix M;
	
	while ( opt != 0 ) {
		cout << "\nPress 1 to Get Numbers." << endl;
		cout << "Press 2 to View Numbers." << endl;
		cout << "Press 3 to Add Numbers." << endl;
		cout << "Press 0 to Exit." << endl;
		cout << "\nEnter Your Choice: ";
		cin >> opt;
		
		switch( opt ) {
			case 1:
				cout << "\nEnter the Size of Row: ";
				cin >> row;
				cout << "\nEnter the Size of Col: ";
				cin >> col;
				if( ! ( ( row > 0 && row < 6 ) && ( col > 0 && col < 6 ) ) ) {
					cout << "\nEntered Order is Invalid.";
				}
				else {
					M.getValues( row, col );
				}
				break;
				
			case 2:
				cout << "\nThe Numbers are: ";
				M.viewValues(row, col);
				cout << endl;
				break;
				
			default:
				break;
		}
	}
	
	return 0;

}
